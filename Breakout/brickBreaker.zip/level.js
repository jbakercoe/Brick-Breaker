//var name;
//scoreText = game.add.text(5, 5, 'Score: 0', {font: '18px Arial', fill: '#0095DD'});

// Score bonus after level complete based on how many lives left
// Score per brick should increase per level

function Level(name){
	this.name = name;
	this.initBricks = initBricks;
}

function initBricks(){
	brickInfo = {
		width: 50,
		height: 50,
		count: {
			row: 7,
			col: 3
		},
		offset: {
			top: 50,
			left: 150
		},
		padding: 10,
		stage: 1
	};
	bricks = game.add.group();
	for(c=0; c < brickInfo.count.col; c++){
		for(r=0; r < brickInfo.count.row; r++){
			var brickX = (r*(brickInfo.width+brickInfo.padding))+brickInfo.offset.left;
			var brickY = (c*(brickInfo.height+brickInfo.padding))+brickInfo.offset.top;

			newBrick = game.add.sprite(brickX, brickY, 'brick');
			switch (this.name) {
				case 2:
					if(c==0){
						newBrick.tint = 1702975; // light green
						newBrick.stage = 2;
					} else{
						newBrick.stage = 1;
					}
					break;
				case 3:
					newBrick.tint = 1702975;
					newBrick.stage = 2;
					break;
				case 4:
					if(c==0) {
						newBrick.tint = 14004483; // dark green
						newBrick.stage = 3;
					}
					else {
						newBrick.tint = 1702975;
						newBrick.stage = 2;
					}
					break;
				case 5:
					newBrick.tint = 14004483;
					newBrick.stage = 3;
				default:

			}
			game.physics.enable(newBrick, Phaser.Physics.ARCADE);
			newBrick.body.immovable = true;
			newBrick.anchor.set(0.5);
			bricks.add(newBrick);
		}
	}
}
