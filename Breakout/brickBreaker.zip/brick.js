function Brick(){
	//this.stage = stage;
}
